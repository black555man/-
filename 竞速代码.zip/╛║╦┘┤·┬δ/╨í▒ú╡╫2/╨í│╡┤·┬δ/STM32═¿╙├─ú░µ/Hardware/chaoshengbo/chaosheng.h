#ifndef __CHAOSHENG_H
#define __CHAOSHENG_H
#include <stdint.h>
#include "sys.h"



void HC_SR04_Init(void);
int16_t sonar_mm(void);
float sonar(void);
void HC_SR04_TIM_Init();
#endif
