#ifndef __SERVO_H
#define __SERVO_H	 
#include "sys.h"
#include "stm32f10x.h" 




void GPIO_Configuration(void);
void TIM_Configuration(void);
void PWM_Configuration(void);

#endif
