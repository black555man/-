#include "stm32f10x.h" //STM32ͷ�ļ�
#include "stdint.h" 
#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "Motor.h" 
#include "Servo.h"    
#include "Traversing.h"
#include "common.h"
#include "OLED.h"
#include "chaosheng.h"
#include "syn6288.h"

uint16_t T;
uint16_t steer_ctrl_num= 1500;   //�����ֵ
volatile uint8_t stop_flag = 0; // 0��ʾ���У�1��ʾͣ��

int main(void)
{	
	
	OLED_Init();
	OLED_ColorTurn(0);//0������ʾ��1 ��ɫ��ʾ
  OLED_DisplayTurn(0);//0������ʾ 1 ��Ļ��ת��ʾ
	OLED_Refresh();	
	RCC_Configuration();
  GPIO_Configuration();
  TIM_Configuration();
  PWM_Configuration();
	HCSR04_Init();
	SG90_TIM5_Init();
	USART3_Init(9600);
	Motor_Gpio_init();  // ��ʼ��GPIO
  MotorPWM2_Init(1199, 2); // ��ʼ��PWM
	Traversing_GPIO_Init();
	while (1)
	{
		if (stop_flag == 1)
    {
        SYN_FrameInfo(2,"[v7][m1][t5]ͣ��");
				delay_s(2);
    }
		
		TIM_SetCompare1(TIM5, 5);
		T = HCSR04_GetValue();
		OLED_ShowChinese(24,0,0,16,1); //16*16 ��
		OLED_ShowNum(43,1,3,1,16,1);
		OLED_ShowChinese(56,0,1,16,1); //16*16 ��
		OLED_ShowChinese(72,0,4,16,1); //16*16 ��
		OLED_ShowChinese(90,0,5,16,1); //16*16 ��
		OLED_ShowChinese(0,16,2,16,1); //16*16 ��
		OLED_ShowChinese(16,16,3,16,1); //16*16 ��
		OLED_ShowString(32, 16, ":", 16, 1);
    OLED_ShowNum(50, 16,T, 2, 16, 1);
		OLED_Refresh();
		Auto_Traversing();  //ִ���Զ�Ѱ��
		
	}
}


