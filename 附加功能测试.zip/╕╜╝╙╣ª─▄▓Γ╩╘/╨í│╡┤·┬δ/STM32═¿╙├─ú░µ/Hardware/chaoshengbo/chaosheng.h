#ifndef __CHAOSHENG_H
#define __CHAOSHENG_H
#include <stdint.h>
#include "sys.h"
#include "stm32f10x.h"

void SG90_TIM5_Init(void);
void HCSR04_Timer_Init(void);
void TIM2_IRQHandler(void);
void HCSR04_Init(void);
void HCSR04_Start(void);
uint16_t HCSR04_GetValue(void);

extern uint16_t Time;

#define Trig_Port GPIOC
#define Trig_Pin GPIO_Pin_5


#define Echo_Port GPIOB
#define Echo_Pin GPIO_Pin_1

#endif


