#ifndef  _TRAVERSING_H
#define  _TRAVERSING_H
#include "stm32f10x.h"


void Auto_Traversing(void);
void Traversing_GPIO_Init(void);
void trace(void);
void motor_direction();
void calc_pid(void);


#endif
