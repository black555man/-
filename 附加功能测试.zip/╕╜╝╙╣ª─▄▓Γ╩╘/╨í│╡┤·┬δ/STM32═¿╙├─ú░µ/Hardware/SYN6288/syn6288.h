#ifndef __SYN6288_H
#define __SYN6288_H

#include "sys.h"

void SYN_TIM1_Init(u16 arr, u16 psc);
void SYN_FrameInfo(u8 Music, u8 *HZdata);
void YS_SYN_Set(u8 *Info_data);

#endif

